#include <tls.h>

#ifdef USE_TLS
#include "tls-macros.h"

COMMON_INT_DEF(bar);
#endif
